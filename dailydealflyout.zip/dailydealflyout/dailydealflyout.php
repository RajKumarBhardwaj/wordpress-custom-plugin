<?php
   /*
   Plugin Name: Dailydealflyout
   Plugin URI: http://apetrail.com
   Description: A plugin to create Daily Deal Flyout In Weekly Process
   Version: 1
   Author: Mr. R.K.Bhardwaj & Mr. Vishwender Baloria Designer : Mr. Punit Sharama
   Author URI: http://apetrail.com
   License: Open Source 
   */
   add_action('admin_menu', 'dailydealflyout_admin_actions');
   function dailydealflyout_admin_actions(){
   add_options_page('Dailydealflyout', 'Dailydealflyout', 'manage_options', __FILE__,'dailydealflyout_admin');
   }
   
   function dailydealflyout_admin()
   {
   ?>
   <div class="daily-wrap">
   <h4>A plugin for daily deal bassed on days.</h4>
   <table class="widefat">
   <thead>
   <tr>
   <th><strong>Days</strong></th>
   <th><strong>Daily Deal</strong></th>
   </tr>
   </thead>
   <tfoot>
   <tr>
   <th><strong>Days</strong></th>
   <th><strong>Daily Deal</strong></th>
   </tr>
   </tfoot>
  
	<?php
	    global $wpdb;
	
	$mydailydeal = $wpdb->get_results(
	"SELECT * FROM wp_deal"
	);
	//echo '<pre>'; print_r($mydailydeal);
	
	$record_id = "";
	
	if(isset($_POST['submit']))
	{
			if(empty($mydailydeal)){
			$wpdb->insert( 
			'wp_deal', 
			array( 
			'deal_on_mon'    => $_POST['monday'],
			'deal_on_tues'    => $_POST['tuesday'],
			'deal_on_wed'    => $_POST['wednesday'],
			'deal_on_thur'    => $_POST['thursday'],
			'deal_on_fri'    => $_POST['friday'],
			'deal_on_sat'    => $_POST['saturday'],
			'deal_on_sun'    => $_POST['sunday'],
			'deal_status'   => 'active'

			));
			$record_id = $wpdb->insert_id;
			}
			else
			{	
				$id = $_POST['dealid'];
				$table = 'wp_deal';
				$data = array( 
				'deal_on_mon'    => $_POST['monday'],
				'deal_on_tues'    => $_POST['tuesday'],
				'deal_on_wed'    => $_POST['wednesday'],
				'deal_on_thur'    => $_POST['thursday'],
				'deal_on_fri'    => $_POST['friday'],
				'deal_on_sat'    => $_POST['saturday'],
				'deal_on_sun'    => $_POST['sunday'],
				'deal_status'   => 'active');
				
				$where = array('deal_id'=>$id);
				$updated = $wpdb->update( $table, $data, $where);

				if ( false === $updated ) {
				echo 'error';
				} else {
				//echo '<strong class="updated settings-error notice is-dismissible">Daily Deal Setting updated</strong>';
				echo "<script>alert('Daily Deal Setting updated!'); location.reload(); </script>";
				}
			}
	}
	
	

	
	?>
   <form method="POST">
   <tbody>
	<tr>
	<td><strong>Monday</strong></td>
	<input type="hidden" name="dealid" value="<?php echo isset($mydailydeal[0]->deal_id) ? $mydailydeal[0]->deal_id : ''; ?>">
	<td><textarea name="monday"><?php echo isset($mydailydeal[0]->deal_on_mon) ? $mydailydeal[0]->deal_on_mon : '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Tuesday</strong></td>
	<td><textarea  name="tuesday"><?php echo isset($mydailydeal[0]->deal_on_tues) ? $mydailydeal[0]->deal_on_tues : '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Wednesday</strong></td>
	<td><textarea  name="wednesday"><?php echo isset($mydailydeal[0]->deal_on_wed) ? $mydailydeal[0]->deal_on_wed : '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Thursday</strong></td>
	<td><textarea  name="thursday"><?php echo isset($mydailydeal[0]->deal_on_thur) ? $mydailydeal[0]->deal_on_thur : '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Friday</strong></td>
	<td><textarea  name="friday"><?php echo isset($mydailydeal[0]->deal_on_fri) ? $mydailydeal[0]->deal_on_fri: '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Saturday</strong></td>
	<td><textarea  name="saturday"><?php echo isset($mydailydeal[0]->deal_on_sat) ? $mydailydeal[0]->deal_on_sat : '';?></textarea></td>
	</tr>
	<tr>
	<td><strong>Sunday</strong></td>
	<td><textarea  name="sunday"><?php echo isset($mydailydeal[0]->deal_on_sun) ? $mydailydeal[0]->deal_on_sun : '';?></textarea></td>
	</tr>
	<tr>
	<td></td>
	<td>
	<?php if(empty($mydailydeal)){ ?>
		<input type = "submit" name="submit" value="save"/>
	<?php }
	else
	{ ?>
		<input type = "submit" name="submit" value="Update"/>	
    <?php 
	} ?>
	
	</td>
	</tr>
   </tbody>
   </form>
   </div>
   <?php } 
   

   
   function dailydeal_front(){
       global $wpdb;
	
	$mydailydeal = $wpdb->get_results(
	"SELECT * FROM wp_deal"
	);
	$day =  date('l');
	//echo '<pre>'; print_r($mydailydeal);
	if($day == "Monday")
	{
		echo $mydailydeal[0]->deal_on_mon;
	}else if($day == "Tuesday")
	{
		echo $mydailydeal[0]->deal_on_tues;
	}
	else if($day == "Wednesday")
	{
		echo $mydailydeal[0]->deal_on_wed;
	}
	else if($day == "Thursday")
	{
		echo $mydailydeal[0]->deal_on_thur;
	}
	else if($day == "Friday")
	{
		echo $mydailydeal[0]->deal_on_fri;
	}
	else if($day == "Saturday")
	{
		echo $mydailydeal[0]->deal_on_sat;
	}
	else
	{
		echo $mydailydeal[0]->deal_on_sun;
	}
   } 
   add_shortcode('dailydeal' ,'dailydeal_front');
   ?>
  <style>
  .daily-wrap thead {
  background: #008ec2 none repeat scroll 0 0;
}
.daily-wrap tfoot {
  background: #008ec2 none repeat scroll 0 0;
}
.daily-wrap th strong {
  color: #fff;
}
.daily-wrap th{
width: 50%
}

.daily-wrap input {
  background: #008ec2 none repeat scroll 0 0;
  color: #fff;
  font-weight: bold;
}
.daily-wrap textarea {
  line-height: 1.4;
  padding: 2px 6px;
  resize: vertical;
  width: 100%;
  border-color: #008ec2 none repeat scroll 0 0;
}
.daily-wrap td {
  border:  solid 1px #ccc;
   1: ;
}
  </style>